create
    definer = root@localhost procedure booksCount(OUT cnt int)
BEGIN
    SELECT COUNT(*) INTO cnt FROM books;
END;

