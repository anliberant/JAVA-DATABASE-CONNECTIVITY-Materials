create
    definer = root@localhost procedure tablesCount()
BEGIN
    SELECT COUNT(*) FROM books;
        SELECT COUNT(*) FROM images;
end;

